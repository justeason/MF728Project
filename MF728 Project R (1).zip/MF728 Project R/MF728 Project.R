library(rmgarch)
library(fGarch)

data <- read.csv('data/Data Interpol.csv')
months <- c(1, seq(3, 60, 3))
data <- data[-1]
colnames(data) <- months
maturities <- months/12
garch11.spec <- ugarchspec(mean.model=list(armaOrder=c(0, 0)),
                           variance.model=list(garchOrder=c(1, 1), model='sGARCH'),
                           distribution.model='norm'
)
dcc.garch11.spec <- dccspec(uspec=multispec(replicate(3, garch11.spec)),
                            dccOrder=c(1, 1),
                            distribution='mvnorm')

var.df <- as.data.frame(matrix(nrow=nrow(data)-751, ncol=3))
colnames(var.df) <- c('1%', '2.5%', '5%')
pred_y <- function(lam, tau, betas){
  term2 = ((1-exp(-lam * tau)) / (lam * tau))
  term3 = term2 - exp(lam * tau)
  return (betas[1] + betas[2] * term2 + betas[3] * term3)
}
calc_resid <- function(x){
  resid = 0
  for (i in c(1:nrow(samp.data))){
    for (j in c(1:length(months))){
      resid <- resid + (pred_y(x, maturities[j], beta.df[i,]) - samp.data[i,j]) ** 2
    }
  }
  return(as.numeric(resid))
}
for (ind in c(1:500)){
  samp.data <- data[1:(750 + ind),]
  # 1. estimate betas
  lamb <- 0.5
  x1 <- (1 - exp(-lamb * maturities)) / (lamb * maturities)
  x2 <- x1 - exp(lamb * maturities)
  beta.df <- as.data.frame(matrix(ncol=3, nrow=nrow(samp.data)))
  colnames(beta.df) <- c('beta0', 'beta1','beta2')
  for(i in c(1:nrow(samp.data))){
    ns.fit <- lm(unlist(samp.data[i,])~ x1 + x2)
    beta.df$beta0[i] <- ns.fit$coefficients[1]
    beta.df$beta1[i] <- ns.fit$coefficients[2]
    beta.df$beta2[i] <- ns.fit$coefficients[3]
  }
  
  
  # 2. estimate optimal lambda
  pred_y <- function(lam, tau, betas){
    term2 = ((1-exp(-lam * tau)) / (lam * tau))
    term3 = term2 - exp(lam * tau)
    return (betas[1] + betas[2] * term2 + betas[3] * term3)
  }
  calc_resid <- function(x){
    resid = 0
    for (i in c(1:nrow(samp.data))){
      for (j in c(1:length(months))){
        resid <- resid + (pred_y(x, maturities[j], beta.df[i,]) - samp.data[i,j]) ** 2
      }
    }
    return(as.numeric(resid))
  }
  # lamb.opt <- optimize(calc_resid, c(0, 1))
  
  
  # 3. get beta AR(1) residuals
  ar.resid.df <- as.data.frame(matrix(ncol=3, nrow=nrow(samp.data) - 1))
  colnames(ar.resid.df) <- colnames(beta.df)
  ar.coef.df <- as.data.frame(matrix(ncol=3, nrow=2))
  colnames(ar.coef.df) <- colnames(beta.df)
  for (i in c(1:ncol(beta.df))){
    x.ar <- beta.df[1:nrow(beta.df)-1, i]
    y.ar <- beta.df[2:nrow(beta.df), i]
    ar <- lm(y.ar~x.ar)
    ar.resid.df[,i]  <- ar$residuals
    ar.coef.df[,i] <- ar$coefficients
  }
  
  # 4. estimate DCC-GARCH parameters
  
  dcc.fit <- dccfit(dcc.garch11.spec, data=ar.resid.df)
  
  # 5. get NS model residuals
  ns.resid.df <- ar.resid.df <- as.data.frame(matrix(ncol=21, nrow=nrow(beta.df)))
  for (i in c(1:length(maturities))){
    ns.resid.df[,i] <- samp.data[,i] - pred_y(0.5, maturities[1], beta.df)
  }
  
  # 7. make predictions to calculate t+1 VaR.
  beta.pred <- rep(0, 3)
  beta.last <- as.matrix(rbind(rep(1, 3), beta.df[nrow(beta.df),]))
  for (i in c(1:3)){
    beta.pred[i] <- as.numeric(t(beta.last[,i]) %*% as.matrix(ar.coef.df[i]))
  }
  lamb.mat <- matrix(nrow=length(maturities), ncol=3)
  lamb.mat[,1] <- rep(1, length(maturities))
  lamb.mat[,2] <- (1-exp(-lamb * maturities))/lamb*maturities
  lamb.mat[,3] <- lamb.mat[,2] - exp(lamb * maturities)
  mu.pred <- rep(0, 21)
  for (i in c(1:21)){
    mu.pred[i] <- pred_y(lamb, maturities[i], beta.pred)
  }
  weights <- rep(1/length(maturities), length(maturities))
  mu.p.pred <- as.numeric(mu.pred %*% weights)
  maturities ** 2
  omega.pred <- dccforecast(dcc.fit)
  omega.pred <- omega.pred@mforecast$H
  omega.pred <- matrix(unlist(omega.pred), nrow=3, ncol=3)
  sigma <- cov(ns.resid.df)
  sigma.pred <- maturities %*% t(maturities) * (lamb.mat %*% omega.pred %*% t(lamb.mat) + sigma)
  sigma.p.pred <- t(weights) %*% sigma.pred %*% weights
  var.df[ind,1] <- mu.p.pred + sigma.p.pred * qnorm(0.01)
  var.df[ind,2] <- mu.p.pred + sigma.p.pred * qnorm(0.025)
  var.df[ind,3] <- mu.p.pred + sigma.p.pred * qnorm(0.05)
  print(ind)
}
apply(data[750:1251,], 1, mean)
write.csv(var.df, 'DCC-GARCH VaR.csv')

